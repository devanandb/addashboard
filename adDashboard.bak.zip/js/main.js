 $(document).ready(function(){
             var plot1 = $.jqplot ('chart1', [[3,7,9,1,4,6,8,2,5]]);
              })           